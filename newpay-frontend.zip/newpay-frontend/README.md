# NewPay Front-end API Ready

Front-end configurado para consumir a API local do NewPay.

## API esperada

```js
const API_BASE_URL = "http://localhost:8080/v1";
```

## Fluxos conectados

### Clientes
- GET `/clientes`
- POST `/clientes`
- PUT `/clientes/{id}`
- DELETE `/clientes/{id}`

### Contas
- GET `/contas`
- POST `/contas/{clienteId}`

### Operações
- POST `/contas/{contaId}/depositos`
- POST `/contas/{contaId}/saques`
- POST `/contas/transferencias`

### Extrato
- GET `/contas/{contaId}/extrato?page=0&size=10`

## Como rodar

Com a API Spring Boot rodando em `localhost:8080`, abra o front com Live Server ou:

```bash
python -m http.server 5500
```

Depois acesse:

```txt
http://localhost:5500/pages/dashboard.html
```
