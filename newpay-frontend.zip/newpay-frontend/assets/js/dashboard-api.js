async function carregarDashboard() {
    try {
        const [clientesResposta, contasResposta] = await Promise.all([
            fetch(`${API_BASE_URL}/clientes`),
            fetch(`${API_BASE_URL}/contas`)
        ]);

        await tratarErro(clientesResposta, "Erro ao buscar clientes");
        await tratarErro(contasResposta, "Erro ao buscar contas");

        const clientes = await clientesResposta.json();
        const contas = await contasResposta.json();

        const saldoTotal = contas.reduce((total, conta) => total + Number(conta.saldo ?? 0), 0);

        document.getElementById("totalClientes").textContent = clientes.length;
        document.getElementById("totalContas").textContent = contas.length;
        document.getElementById("saldoTotal").textContent = formatarMoeda(saldoTotal);

    } catch (erro) {
        console.error("Erro ao carregar dashboard:", erro);
    }
}

document.addEventListener("DOMContentLoaded", carregarDashboard);
