async function depositar(event) {
    event.preventDefault();

    const form = event.target;

    const contaId = form.contaId.value;

    const deposito = {
        valor: form.valor.value
    };

    try {
        const resposta = await fetch(`${API_BASE_URL}/contas/${contaId}/depositos`, {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(deposito)
        });

        await tratarErro(resposta, "Erro ao realizar depósito");

        alert("Depósito realizado com sucesso!");

        form.reset();

    } catch (erro) {
        console.error("Erro ao depositar:", erro);
        alert(erro.message);
    }
}

async function sacar(event) {
    event.preventDefault();

    const form = event.target;

    const contaId = form.contaId.value;

    const saque = {
        valor: form.valor.value
    };

    try {
        const resposta = await fetch(`${API_BASE_URL}/contas/${contaId}/saques`, {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(saque)
        });

        await tratarErro(resposta, "Erro ao realizar saque");

        alert("Saque realizado com sucesso!");

        form.reset();

    } catch (erro) {
        console.error("Erro ao sacar:", erro);
        alert(erro.message);
    }
}

async function transferir(event) {
    event.preventDefault();

    const form = event.target;

    const transferencia = {
        contaOrigemId: form.contaOrigemId.value,
        contaDestinoId: form.contaDestinoId.value,
        valor: form.valor.value
    };

    try {
        const resposta = await fetch(`${API_BASE_URL}/contas/transferencias`, {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(transferencia)
        });

        await tratarErro(resposta, "Erro ao realizar transferência");

        alert("Transferência realizada com sucesso!");

        form.reset();

    } catch (erro) {
        console.error("Erro ao transferir:", erro);
        alert(erro.message);
    }
}

document.addEventListener("DOMContentLoaded", () => {
    document.getElementById("depositoForm")?.addEventListener("submit", depositar);
    document.getElementById("saqueForm")?.addEventListener("submit", sacar);
    document.getElementById("transferenciaForm")?.addEventListener("submit", transferir);
});
