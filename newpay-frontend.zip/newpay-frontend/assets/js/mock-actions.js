document.querySelectorAll('form').forEach((form) => {
  form.addEventListener('submit', (event) => {
    event.preventDefault();
    window.NewPayUI?.showToast('Layout pronto. No próximo passo conectamos esse formulário na API.');
  });
});
