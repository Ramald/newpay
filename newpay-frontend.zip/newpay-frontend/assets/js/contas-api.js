async function carregarContas() {
    const tabela = document.getElementById("contasTable");

    tabela.innerHTML = `
        <tr>
            <td colspan="5">Carregando contas...</td>
        </tr>
    `;

    try {
        const resposta = await fetch(`${API_BASE_URL}/contas`);
        await tratarErro(resposta, "Erro ao buscar contas");

        const contas = await resposta.json();

        tabela.innerHTML = "";

        if (contas.length === 0) {
            tabela.innerHTML = `
                <tr>
                    <td colspan="5">Nenhuma conta cadastrada.</td>
                </tr>
            `;
            return;
        }

        contas.forEach(conta => {
            const linha = document.createElement("tr");

            linha.innerHTML = `
                <td>${conta.id}</td>
                <td>${conta.numeroConta}</td>
                <td>${conta.clienteId}</td>
                <td>${formatarMoeda(conta.saldo)}</td>
                <td><span class="badge success">Ativa</span></td>
            `;

            tabela.appendChild(linha);
        });

    } catch (erro) {
        console.error("Erro ao carregar contas:", erro);

        tabela.innerHTML = `
            <tr>
                <td colspan="5">Erro ao carregar contas.</td>
            </tr>
        `;
    }
}

async function abrirConta(event) {
    event.preventDefault();

    const form = event.target;
    const clienteId = form.clienteId.value;

    try {
        const resposta = await fetch(`${API_BASE_URL}/contas/${clienteId}`, {
            method: "POST"
        });

        await tratarErro(resposta, "Erro ao abrir conta");

        alert("Conta aberta com sucesso!");

        form.reset();

        carregarContas();

    } catch (erro) {
        console.error("Erro ao abrir conta:", erro);
        alert(erro.message);
    }
}

document.addEventListener("DOMContentLoaded", () => {
    carregarContas();

    const contaForm = document.getElementById("contaForm");

    if (contaForm) {
        contaForm.addEventListener("submit", abrirConta);
    }
});
