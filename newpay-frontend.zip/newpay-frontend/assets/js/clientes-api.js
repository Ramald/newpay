let clienteEditandoId = null;
let clientesCache = [];

async function carregarClientes() {
    const tabela = document.getElementById("clientesTable");

    tabela.innerHTML = `
        <tr>
            <td colspan="5">Carregando clientes...</td>
        </tr>
    `;

    try {
        const resposta = await fetch(`${API_BASE_URL}/clientes`);
        await tratarErro(resposta, "Erro ao buscar clientes");

        const clientes = await resposta.json();
        clientesCache = clientes;

        tabela.innerHTML = "";

        if (clientes.length === 0) {
            tabela.innerHTML = `
                <tr>
                    <td colspan="5">Nenhum cliente cadastrado.</td>
                </tr>
            `;
            return;
        }

        clientes.forEach(cliente => {
            const linha = document.createElement("tr");

            linha.innerHTML = `
                <td>${cliente.id}</td>
                <td>${cliente.nome}</td>
                <td>${cliente.cpf}</td>
                <td>${cliente.email}</td>
                <td class="row-actions">
                    <button class="icon-btn btn-editar" data-id="${cliente.id}">✏️</button>
                    <button class="icon-btn btn-deletar" data-id="${cliente.id}">🗑️</button>
                </td>
            `;

            tabela.appendChild(linha);
        });

    } catch (erro) {
        console.error("Erro ao carregar clientes:", erro);

        tabela.innerHTML = `
            <tr>
                <td colspan="5">Erro ao carregar clientes.</td>
            </tr>
        `;
    }
}

function prepararEdicaoCliente(id) {
    const cliente = clientesCache.find(item => item.id === Number(id));

    if (!cliente) {
        alert("Cliente não encontrado na tabela.");
        return;
    }

    const form = document.getElementById("clienteForm");

    clienteEditandoId = cliente.id;

    form.nome.value = cliente.nome;
    form.cpf.value = cliente.cpf;
    form.email.value = cliente.email;
    form.dataNascimento.value = cliente.dataNascimento;

    const botao = form.querySelector("button[type='submit']");
    botao.textContent = "Atualizar cliente";
}

async function atualizarCliente(cliente) {
    const form = document.getElementById("clienteForm");

    try {
        const resposta = await fetch(`${API_BASE_URL}/clientes/${clienteEditandoId}`, {
            method: "PUT",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(cliente)
        });

        await tratarErro(resposta, "Erro ao atualizar cliente");

        alert("Cliente atualizado com sucesso!");

        clienteEditandoId = null;
        form.reset();

        const botao = form.querySelector("button[type='submit']");
        botao.textContent = "Cadastrar cliente";

        carregarClientes();

    } catch (erro) {
        console.error("Erro ao atualizar cliente:", erro);
        alert(erro.message);
    }
}

async function deletarCliente(id) {
    const confirmar = confirm("Tem certeza que deseja deletar este cliente?");

    if (!confirmar) return;

    try {
        const resposta = await fetch(`${API_BASE_URL}/clientes/${id}`, {
            method: "DELETE"
        });

        await tratarErro(resposta, "Erro ao deletar cliente");

        alert("Cliente deletado com sucesso!");

        carregarClientes();

    } catch (erro) {
        console.error("Erro ao deletar cliente:", erro);
        alert(erro.message);
    }
}

async function salvarCliente(event) {
    event.preventDefault();

    const form = event.target;

    const cliente = {
        nome: form.nome.value,
        cpf: form.cpf.value,
        email: form.email.value,
        dataNascimento: form.dataNascimento.value
    };

    if (clienteEditandoId !== null) {
        await atualizarCliente(cliente);
        return;
    }

    try {
        const resposta = await fetch(`${API_BASE_URL}/clientes`, {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(cliente)
        });

        await tratarErro(resposta, "Erro ao cadastrar cliente");

        form.reset();

        alert("Cliente cadastrado com sucesso!");

        carregarClientes();

    } catch (erro) {
        console.error("Erro ao cadastrar cliente:", erro);
        alert(erro.message);
    }
}

document.addEventListener("DOMContentLoaded", () => {
    carregarClientes();

    const clienteForm = document.getElementById("clienteForm");

    if (clienteForm) {
        clienteForm.addEventListener("submit", salvarCliente);
    }

    document.getElementById("clientesTable").addEventListener("click", event => {
        const botaoEditar = event.target.closest(".btn-editar");
        const botaoDeletar = event.target.closest(".btn-deletar");

        if (botaoEditar) {
            prepararEdicaoCliente(botaoEditar.dataset.id);
        }

        if (botaoDeletar) {
            deletarCliente(botaoDeletar.dataset.id);
        }
    });
});
