async function buscarExtrato(event) {
    event.preventDefault();

    const form = event.target;
    const tabela = document.getElementById("extratoTable");
    const paginaBadge = document.getElementById("paginaAtual");

    const contaId = form.contaId.value;
    const page = form.page.value || 0;
    const size = form.size.value || 10;

    tabela.innerHTML = `
        <tr>
            <td colspan="3">Carregando extrato...</td>
        </tr>
    `;

    try {
        const resposta = await fetch(`${API_BASE_URL}/contas/${contaId}/extrato?page=${page}&size=${size}`);
        await tratarErro(resposta, "Erro ao buscar extrato");

        const dados = await resposta.json();

        const movimentacoes = Array.isArray(dados) ? dados : dados.content;
        const paginaAtual = Array.isArray(dados) ? Number(page) : dados.number;

        if (paginaBadge) {
            paginaBadge.textContent = `Página ${paginaAtual}`;
        }

        tabela.innerHTML = "";

        if (!movimentacoes || movimentacoes.length === 0) {
            tabela.innerHTML = `
                <tr>
                    <td colspan="3">Nenhuma movimentação encontrada.</td>
                </tr>
            `;
            return;
        }

        movimentacoes.forEach(movimentacao => {
            const tipo = movimentacao.tipo;
            const isEntrada = tipo === "DEPOSITO" || tipo === "TRANSFERENCIA_ENTRADA";
            const classe = isEntrada ? "success" : "danger";

            const linha = document.createElement("tr");

            linha.innerHTML = `
                <td><span class="badge ${classe}">${tipo}</span></td>
                <td>${formatarMoeda(movimentacao.valor)}</td>
                <td>${formatarDataHora(movimentacao.dataHora)}</td>
            `;

            tabela.appendChild(linha);
        });

    } catch (erro) {
        console.error("Erro ao buscar extrato:", erro);

        tabela.innerHTML = `
            <tr>
                <td colspan="3">Erro ao buscar extrato.</td>
            </tr>
        `;

        alert(erro.message);
    }
}

document.addEventListener("DOMContentLoaded", () => {
    const extratoForm = document.getElementById("extratoForm");

    if (extratoForm) {
        extratoForm.addEventListener("submit", buscarExtrato);
    }
});
