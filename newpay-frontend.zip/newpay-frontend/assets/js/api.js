const API_BASE_URL = "http://localhost:8080/v1";

function formatarMoeda(valor) {
    const numero = Number(valor ?? 0);
    return numero.toLocaleString("pt-BR", {
        style: "currency",
        currency: "BRL"
    });
}

function formatarDataHora(dataHora) {
    if (!dataHora) return "-";

    const data = new Date(dataHora);

    if (Number.isNaN(data.getTime())) {
        return dataHora;
    }

    return data.toLocaleString("pt-BR");
}

async function tratarErro(resposta, mensagemPadrao) {
    if (resposta.ok) return;

    let mensagem = mensagemPadrao;

    try {
        const texto = await resposta.text();
        if (texto) mensagem = texto;
    } catch (erro) {
        console.error("Erro ao ler resposta da API:", erro);
    }

    throw new Error(mensagem);
}
